﻿namespace HHH.Common
{
    interface IOnRecycle
    {
        void OnRecycle();
    }
}