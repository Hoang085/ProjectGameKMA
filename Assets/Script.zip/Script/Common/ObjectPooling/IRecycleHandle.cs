﻿namespace HHH.Common
{
    public interface IRecycleHandle
    {
        void SetRecycle(float delayTime);
    }
}