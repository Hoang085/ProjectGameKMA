﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using HHH.Common;

// Quan ly giao dien nguoi dung trong game
public class GameUIManager : Singleton<GameUIManager>
{
    [Header("Prompt")]
    public GameObject interactPromptRoot;
    public Text interactPromptText;
    public KeyCode defaultInteractKey = KeyCode.F;

    [Header("Dialogue")]
    public GameObject dialogueRoot;
    public Text dialogueNpcNameText;
    public Text dialogueContentText;

    [Header("Note Popup")]
    public NotePopup notePopupPrefab;
    public Transform popupParent;
    private bool _dialogueOpen;
    public bool IsDialogueOpen => _dialogueOpen;

    [Header("BtnListIcon")]
    [SerializeField] private Button btnPlayerIcon;
    [SerializeField] private Button btnBaloIcon;
    [SerializeField] private Button btnTaskIcon;
    [SerializeField] private Button btnScoreIcon;
    [SerializeField] private Button btnScheduleIcon; // Thêm button lịch học
    [SerializeField] private Button btnSettingIcon;  // Thêm button cài đặt

    [Header("Backpack/Balo")]
    public BackpackUIManager backpackUIManager;

    [Header("End Of Semester")]
    [SerializeField] private EndOfSemesterNotice endOfSemesterNotice; // component trên object trên

    // ========== THEO DÕI TRẠNG THÁI UI ==========
    /// <summary>
    /// Kiểm tra có bất kỳ UI nào đang mở không (bao gồm cả dialogue)
    /// </summary>
    public bool IsAnyUIOpen => _dialogueOpen || IsAnyStatUIOpen;

    /// <summary>
    /// Kiểm tra có UI thống kê nào đang mở không
    /// </summary>
    public bool IsAnyStatUIOpen;

    private TeacherAction _activeTeacher;
    public void BindTeacher(TeacherAction t) { _activeTeacher = t; }
    public void UnbindTeacher(TeacherAction t) { if (_activeTeacher == t) _activeTeacher = null; }

    /// <summary>
    /// Get task count from TaskManager (new unified source)
    /// </summary>
    public int GetActiveTaskCount()
    {
        if (TaskManager.Instance != null)
        {
            return TaskManager.Instance.GetActiveTaskCount();
        }
        return 0;
    }

    /// <summary>
    /// Check if TaskManager has pending tasks
    /// </summary>
    public bool HasPendingTasks()
    {
        if (TaskManager.Instance != null)
        {
            return TaskManager.Instance.HasPendingTasks();
        }
        return false;
    }

    /// <summary>
    /// Refresh task notification through GameManager
    /// </summary>
    public void RefreshTaskNotification()
    {
        if (GameManager.Ins != null)
        {
            GameManager.Ins.RefreshIconNotification(IconType.Task);
        }
    }

    /// <summary>
    /// Called when a new task is added - NO LONGER NEEDED (TaskManager handles this)
    /// </summary>
    public void OnTaskAdded()
    {
        // TaskManager now handles notification directly
        Debug.Log("[GameUIManager] Task added - TaskManager handles notification");
    }

    /// <summary>
    /// Called when a task is completed/removed - NO LONGER NEEDED (TaskManager handles this)
    /// </summary>
    public void OnTaskCompleted()
    {
        // TaskManager now handles notification directly
        Debug.Log("[GameUIManager] Task completed - TaskManager handles notification");
    }

    public void OnClick_TakeExam()
    {
        if (_activeTeacher == null)
        {
            Debug.LogWarning("[GameUIManager] OnClick_TakeExam nhưng chưa có activeTeacher!");
            return;
        }
        _activeTeacher.UI_TakeExam();
    }

    // Bat dau lop hoc khi nhan nut
    public void OnClick_StartClass()
    {
        if (_activeTeacher == null)
        {
            Debug.LogWarning("[GameUIManager] OnClick_StartClass nhưng chưa có activeTeacher!");
            return;
        }

        Debug.Log($"[GameUIManager] StartClass gọi tới teacher: {_activeTeacher.name}");
        _activeTeacher.UI_StartClass(); // Gọi bắt đầu lớp

        // 🔐 LƯU TRẠNG THÁI TRƯỚC KHI RỜI GAMESCENE
        GameStateManager.SavePreExamState($"CLASS:{_activeTeacher.name}");

        // 🔁 Đặt flag để GameManager biết phải khôi phục khi quay về từ MiniGame
        PlayerPrefs.SetInt("ShouldRestoreStateAfterMiniGame", 1);
        PlayerPrefs.Save();

        // ⏱️ Bảo đảm không bị pause dở dang
        Time.timeScale = 1f;

        //StartCoroutine(DelayedLoadMiniGame());
    }

    private IEnumerator DelayedLoadMiniGame()
    {
        yield return new WaitForSeconds(2.5f); // chờ 2–3s tùy animation của bạn
        SceneManager.LoadScene("MiniGameScene1");
    }

    // ========== XỬ LÝ SỰ KIỆN CLICK ICON ==========
    public void OnClick_PlayerIcon()
    {
        if (_dialogueOpen)
        {
            Debug.Log("[GameUIManager] Không thể mở Player UI khi đang trong dialogue");
            return;
        }

        if (GameManager.Ins != null)
            GameManager.Ins.OnIconClicked(IconType.Player);

        CloseAllUIs(); 
        PopupManager.Ins.OnShowScreen(PopupName.PlayerStat);
        Debug.Log("[GameUIManager] Đã mở PlayerStatsUI (popup)");
    }

    public void OnClick_BaloIcon()
    {
        if (_dialogueOpen)
        {
            Debug.Log("[GameUIManager] Không thể mở Balo UI khi đang trong dialogue");
            return;
        }

        if (GameManager.Ins != null)
            GameManager.Ins.OnIconClicked(IconType.Balo);

        CloseAllUIs(); // đóng UI legacy
        PopupManager.Ins.OnShowScreen(PopupName.BaloPlayer);   //  mở popup Balo
        Debug.Log("[GameUIManager] Đã mở BaloPlayer (popup)");
    }


    public void OnClick_TaskIcon()
    {
        // Ngăn click khi dialogue đang mở
        if (_dialogueOpen)
        {
            Debug.Log("[GameUIManager] Không thể mở Task UI khi đang trong dialogue");
            return;
        }

        // Clear notification when icon is clicked
        if (GameManager.Ins != null)
        {
            GameManager.Ins.OnIconClicked(IconType.Task);
        }

        CloseAllUIs(); // đóng UI legacy
        PopupManager.Ins.OnShowScreen(PopupName.TaskPlayer);   //  mở popup Balo
        Debug.Log("[GameUIManager] Đã mở Task UI");
    }

    public void OnClick_ScoreIcon()
    {
        // Ngăn click khi dialogue đang mở
        if (_dialogueOpen)
        {
            Debug.Log("[GameUIManager] Không thể mở Score UI khi đang trong dialogue");
            return;
        }

        // Clear notification when icon is clicked
        if (GameManager.Ins != null)
        {
            GameManager.Ins.OnIconClicked(IconType.Score);
        }

        CloseAllUIs(); // đóng UI legacy
        PopupManager.Ins.OnShowScreen(PopupName.ScoreSubject);
        Debug.Log("[GameUIManager] Đã mở Score UI");
    }

    public void OnClick_ScheduleIcon()
    {
        if (_dialogueOpen)
        {
            Debug.Log("[GameUIManager] Không thể mở Schedule UI khi đang trong dialogue");
            return;
        }
        CloseAllUIs();
        PopupManager.Ins.OnShowScreen(PopupName.ScheduleUI);
        Debug.Log("[GameUIManager] Đã mở Schedule UI");
    }

    public void OnClick_SettingIcon()
    {
        if (_dialogueOpen)
        {
            Debug.Log("[GameUIManager] Không thể mở Setting UI khi đang trong dialogue");
            return;
        }
        CloseAllUIs();
        PopupManager.Ins.OnShowScreen(PopupName.Setting);
        Debug.Log("[GameUIManager] Đã mở Setting UI");

    }

    /// <summary>
    /// Đóng tất cả UI thống kê (trừ dialogue và interact prompt)
    /// </summary>
    public void CloseAllUIs()
    {
        Debug.Log("[GameUIManager] Đóng tất cả UI thống kê");
    }

    public override void Awake()
    {
        MakeSingleton(false);

        // Đăng ký sự kiện đổi kỳ
        if (GameClock.Ins != null)
            GameClock.Ins.OnTermChanged += HandleTermChanged_EOS;

        // Ẩn các UI khi khởi tạo
        if (interactPromptRoot) interactPromptRoot.SetActive(false);
        if (dialogueRoot) dialogueRoot.SetActive(false);
        CloseAllUIs();

        SetupIconButtonEvents();
    }

    void Start()
    {

    }

    /// <summary>
    /// Thiết lập sự kiện click cho các nút icon
    /// </summary>
    private void SetupIconButtonEvents()
    {
        if (btnPlayerIcon != null)
            btnPlayerIcon.onClick.AddListener(OnClick_PlayerIcon);

        if (btnBaloIcon != null)
            btnBaloIcon.onClick.AddListener(OnClick_BaloIcon);

        if (btnTaskIcon != null)
            btnTaskIcon.onClick.AddListener(OnClick_TaskIcon);

        if (btnScoreIcon != null)
            btnScoreIcon.onClick.AddListener(OnClick_ScoreIcon);

        if (btnScheduleIcon != null)
            btnScheduleIcon.onClick.AddListener(OnClick_ScheduleIcon);

        if (btnSettingIcon != null)
            btnSettingIcon.onClick.AddListener(OnClick_SettingIcon);
    }

    /// <summary>
    /// Hủy đăng ký sự kiện khi destroy object để tránh memory leak
    /// </summary>
    protected override void OnDestroy()
    {
        if (btnPlayerIcon != null)
            btnPlayerIcon.onClick.RemoveListener(OnClick_PlayerIcon);

        if (btnBaloIcon != null)
            btnBaloIcon.onClick.RemoveListener(OnClick_BaloIcon);

        if (btnTaskIcon != null)
            btnTaskIcon.onClick.RemoveListener(OnClick_TaskIcon);

        if (btnScoreIcon != null)
            btnScoreIcon.onClick.RemoveListener(OnClick_ScoreIcon);

        if (btnScheduleIcon != null)
            btnScheduleIcon.onClick.RemoveListener(OnClick_ScheduleIcon);

        if (btnSettingIcon != null)
            btnSettingIcon.onClick.RemoveListener(OnClick_SettingIcon);

        if (GameClock.Ins != null)
            GameClock.Ins.OnTermChanged -= HandleTermChanged_EOS;
    }

    private void HandleTermChanged_EOS()
    {
        if (endOfSemesterNotice == null) return;

        int term = GameClock.Ins != null ? GameClock.Ins.Term : 1;
        EndOfSemesterNotice.TryShowForTerm(term);
    }

    // Hien thi goi y tuong tac
    public void ShowInteractPrompt(KeyCode key = KeyCode.None)
    {
        if (_dialogueOpen) return;
        var useKey = key == KeyCode.None ? defaultInteractKey : key;
        if (interactPromptText)
            interactPromptText.text = $"Nhấn {useKey}: Nói chuyện";
        if (interactPromptRoot) interactPromptRoot.SetActive(true);
    }

    // An goi y tuong tac
    public void HideInteractPrompt()
    {
        if (interactPromptRoot) interactPromptRoot.SetActive(false);
    }

    // Mo hop thoai
    public void OpenDialogue(string title, string content)
    {
        _dialogueOpen = true;
        HideInteractPrompt();
        if (dialogueNpcNameText) dialogueNpcNameText.text = title;
        if (dialogueContentText) dialogueContentText.text = content;
        if (dialogueRoot) dialogueRoot.SetActive(true);
    }

    // Dong hop thoai
    public void CloseDialogue()
    {
        _dialogueOpen = false;
        if (dialogueRoot) dialogueRoot.SetActive(false);
    }

    // Lay hoac tao popup ghi chu
    public NotePopup GetOrCreateNotePopup()
    {
        if (NotePopup.Instance) return NotePopup.Instance;

        if (!notePopupPrefab)
        {
            Debug.LogError("[GameUIManager] notePopupPrefab chưa được gán. Kéo prefab vào GameUIManager.");
            return null;
        }
        var popup = Instantiate(notePopupPrefab);
        popup.gameObject.SetActive(false); 

        Transform targetParent = null;
        Canvas[] canvases = FindObjectsByType<Canvas>(FindObjectsSortMode.None);

        foreach (var canvas in canvases)
        {
            if (canvas.gameObject.scene.name != null &&
                canvas.gameObject.scene.name.Equals("DontDestroyOnLoad"))
            {
                targetParent = canvas.transform;
                Debug.Log($"[GameUIManager] Tìm thấy Canvas trong DontDestroyOnLoad: {canvas.name}");
                break;
            }
        }

        if (targetParent == null)
        {
            foreach (var canvas in canvases)
            {
                if (canvas.gameObject.scene.name != null &&
                    !canvas.gameObject.scene.name.Equals("DontDestroyOnLoad"))
                {
                    targetParent = canvas.transform;
                    Debug.Log($"[GameUIManager] Fallback: Tìm thấy Canvas trong scene: {canvas.name}");
                    break;
                }
            }
        }

        if (targetParent != null)
        {
            popup.transform.SetParent(targetParent, false);
            Debug.Log($"[GameUIManager] Đã gán NotePopup vào Canvas: {targetParent.name}");
        }
        else
        {
            Debug.LogWarning("[GameUIManager] Không tìm thấy Canvas, NotePopup sẽ ở root!");
        }

        RectTransform rectTransform = popup.GetComponent<RectTransform>();
        if (rectTransform != null)
        {
            // Đặt anchor ở giữa màn hình
            rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            rectTransform.pivot = new Vector2(0.5f, 0.5f);

            rectTransform.anchoredPosition = new Vector2(0f, -100f);

            Debug.Log($"[GameUIManager] Đã điều chỉnh vị trí NotePopup: {rectTransform.anchoredPosition}");
        }

        popup.transform.SetAsLastSibling();
        Debug.Log($"[GameUIManager] Đã đặt NotePopup làm last sibling (index: {popup.transform.GetSiblingIndex()})");

        popup.gameObject.SetActive(true);
        return popup;
    }
}