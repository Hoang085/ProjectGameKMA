﻿using UnityEngine;
using System.Collections.Generic;

[DisallowMultipleComponent]
public class IconNotificationManager : MonoBehaviour
{
    [Header("Notification Points (PointRed GameObjects)")]
    [SerializeField] private GameObject playerIconPointRed;
    [SerializeField] private GameObject baloIconPointRed;
    [SerializeField] private GameObject taskIconPointRed;
    [SerializeField] private GameObject scoreIconPointRed;

    // Dictionary to map icon types to their notification GameObjects
    private Dictionary<IconType, GameObject> notificationPoints;

    void Awake()
    {
        InitializeNotificationPoints();

        // Hide all notifications initially
        foreach (var kvp in notificationPoints)
        {
            if (kvp.Value != null)
            {
                kvp.Value.SetActive(false);
            }
        }
    }

    void Start()
    {
        // Auto-find PointRed objects if not assigned
        AutoFindNotificationPoints();
    }

    private void InitializeNotificationPoints()
    {
        notificationPoints = new Dictionary<IconType, GameObject>
        {
            { IconType.Player, playerIconPointRed },
            { IconType.Balo, baloIconPointRed },
            { IconType.Task, taskIconPointRed },
            { IconType.Score, scoreIconPointRed }
        };
    }

    private void AutoFindNotificationPoints()
    {
        // Try to auto-find PointRed objects based on common naming patterns
        if (playerIconPointRed == null)
            playerIconPointRed = FindNotificationPoint("BtnPlayerStats", "PointRed");

        if (baloIconPointRed == null)
            baloIconPointRed = FindNotificationPoint("BtnPlayerBalo", "PointRed");

        if (taskIconPointRed == null)
            taskIconPointRed = FindNotificationPoint("BtnPlayerTask", "PointRed");

        if (scoreIconPointRed == null)
            scoreIconPointRed = FindNotificationPoint("ButtonListScore", "PointRed");

        // Update dictionary with found objects
        InitializeNotificationPoints();

        // Log what was found
        foreach (var kvp in notificationPoints)
        {
            if (kvp.Value != null)
            {
                Debug.Log($"[IconNotificationManager] Found PointRed for {kvp.Key}: {kvp.Value.name}");
            }
            else
            {
                Debug.LogWarning($"[IconNotificationManager] PointRed not found for {kvp.Key}");
            }
        }
    }

    private GameObject FindNotificationPoint(string parentName, string childName)
    {
        // Find parent object by name
        GameObject parent = GameObject.Find(parentName);
        if (parent == null)
        {
            // Try to find in all GameObjects (less efficient but more thorough)
            GameObject[] allObjects = FindObjectsOfType<GameObject>();
            foreach (GameObject obj in allObjects)
            {
                if (obj.name.Contains(parentName))
                {
                    parent = obj;
                    break;
                }
            }
        }

        if (parent != null)
        {
            // Look for child with specified name
            Transform child = parent.transform.Find(childName);
            if (child != null)
            {
                return child.gameObject;
            }

            // If direct child not found, search recursively
            return FindChildRecursive(parent.transform, childName);
        }

        return null;
    }

    private GameObject FindChildRecursive(Transform parent, string childName)
    {
        for (int i = 0; i < parent.childCount; i++)
        {
            Transform child = parent.GetChild(i);
            if (child.name == childName)
            {
                return child.gameObject;
            }

            GameObject found = FindChildRecursive(child, childName);
            if (found != null)
            {
                return found;
            }
        }
        return null;
    }

    /// <summary>
    /// Set notification visibility for specific icon type
    /// </summary>
    /// <param name="iconType">Type of icon</param>
    /// <param name="visible">Whether notification should be visible</param>
    public void SetNotificationVisible(IconType iconType, bool visible)
    {
        if (notificationPoints.ContainsKey(iconType) && notificationPoints[iconType] != null)
        {
            notificationPoints[iconType].SetActive(visible);
            Debug.Log($"[IconNotificationManager] {iconType} notification set to {visible}");
        }
        else
        {
            Debug.LogWarning($"[IconNotificationManager] PointRed not found for {iconType}");
        }
    }

    /// <summary>
    /// Get current notification visibility for specific icon type
    /// </summary>
    /// <param name="iconType">Type of icon</param>
    /// <returns>True if notification is currently visible</returns>
    public bool IsNotificationVisible(IconType iconType)
    {
        if (notificationPoints.ContainsKey(iconType) && notificationPoints[iconType] != null)
        {
            return notificationPoints[iconType].activeSelf;
        }
        return false;
    }

    /// <summary>
    /// Manually assign notification point for specific icon type
    /// </summary>
    /// <param name="iconType">Type of icon</param>
    /// <param name="notificationObject">GameObject representing the red point</param>
    public void AssignNotificationPoint(IconType iconType, GameObject notificationObject)
    {
        if (notificationPoints.ContainsKey(iconType))
        {
            notificationPoints[iconType] = notificationObject;
            Debug.Log($"[IconNotificationManager] Manually assigned PointRed for {iconType}");
        }
    }
}