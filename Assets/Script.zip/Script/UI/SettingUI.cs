using UnityEngine;
using HHH.Common;

public class SettingUI : BasePopUp
{
    public override void OnInitScreen()
    {
        base.OnInitScreen();
    }
}
