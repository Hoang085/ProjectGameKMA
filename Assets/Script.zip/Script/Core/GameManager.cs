﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GameManager : Singleton<GameManager>
{
    [Header("Icon Notification System")]
    [SerializeField] private IconNotificationManager iconNotificationManager;
    
    // Events for icon notifications
    public event Action<IconType> OnIconNotificationChanged;
    
    // Dictionary to track notification states
    private Dictionary<IconType, bool> iconNotificationStates = new Dictionary<IconType, bool>();
    
    void Start()
    {
        InitializeIconNotifications();
    }

    void Update()
    {
        // Check for changes that might trigger notifications
        CheckForNotificationTriggers();
    }
    
    private void InitializeIconNotifications()
    {
        // Initialize all icon types as not having notifications
        foreach (IconType iconType in System.Enum.GetValues(typeof(IconType)))
        {
            iconNotificationStates[iconType] = false;
        }
        
        // Get reference to IconNotificationManager if not assigned
        if (iconNotificationManager == null)
        {
            iconNotificationManager = FindFirstObjectByType<IconNotificationManager>();
        }
    }
    
    private void CheckForNotificationTriggers()
    {
        // Check for various conditions that should trigger notifications
        CheckPlayerStatsNotification();
        CheckTaskNotification();
        CheckBaloNotification();
        CheckScoreNotification();
    }
    
    private void CheckPlayerStatsNotification()
    {
        // Example: Show notification if stamina is low or stats changed
        bool shouldShow = false;
        
        // Add your specific conditions here
        // Example: if (playerStamina < 30) shouldShow = true;
        
        SetIconNotification(IconType.Player, shouldShow);
    }
    
    private void CheckTaskNotification()
    {
        // Example: Show notification if new tasks are available
        bool shouldShow = false;
        
        // Add your specific conditions here
        // Example: if (hasNewTasks) shouldShow = true;
        
        SetIconNotification(IconType.Task, shouldShow);
    }
    
    private void CheckBaloNotification()
    {
        // Example: Show notification if new items added to backpack
        bool shouldShow = false;
        
        // Add your specific conditions here
        // Example: if (hasNewItems) shouldShow = true;
        
        SetIconNotification(IconType.Balo, shouldShow);
    }
    
    private void CheckScoreNotification()
    {
        // Example: Show notification if new scores are available
        bool shouldShow = false;
        
        // Add your specific conditions here
        // Example: if (hasNewScores) shouldShow = true;
        
        SetIconNotification(IconType.Score, shouldShow);
    }
    
    /// <summary>
    /// Set notification state for a specific icon
    /// </summary>
    /// <param name="iconType">Type of icon</param>
    /// <param name="showNotification">Whether to show or hide notification</param>
    public void SetIconNotification(IconType iconType, bool showNotification)
    {
        if (!iconNotificationStates.ContainsKey(iconType))
        {
            iconNotificationStates[iconType] = false;
        }
        
        if (iconNotificationStates[iconType] != showNotification)
        {
            iconNotificationStates[iconType] = showNotification;
            
            // Update UI
            if (iconNotificationManager != null)
            {
                iconNotificationManager.SetNotificationVisible(iconType, showNotification);
            }
            
            // Trigger event
            OnIconNotificationChanged?.Invoke(iconType);
        }
    }
    
    /// <summary>
    /// Get current notification state for an icon
    /// </summary>
    /// <param name="iconType">Type of icon</param>
    /// <returns>True if notification should be shown</returns>
    public bool GetIconNotification(IconType iconType)
    {
        return iconNotificationStates.ContainsKey(iconType) && iconNotificationStates[iconType];
    }
    
    /// <summary>
    /// Clear notification when player clicks on icon
    /// </summary>
    /// <param name="iconType">Type of icon that was clicked</param>
    public void OnIconClicked(IconType iconType)
    {
        SetIconNotification(iconType, false);
        Debug.Log($"[GameManager] Icon {iconType} clicked - notification cleared");
    }
    
    /// <summary>
    /// Manually trigger notification for specific icon (for external systems)
    /// </summary>
    /// <param name="iconType">Type of icon</param>
    public void TriggerIconNotification(IconType iconType)
    {
        SetIconNotification(iconType, true);
        Debug.Log($"[GameManager] Notification triggered for icon {iconType}");
    }
    
    /// <summary>
    /// Clear all notifications
    /// </summary>
    public void ClearAllNotifications()
    {
        foreach (IconType iconType in System.Enum.GetValues(typeof(IconType)))
        {
            SetIconNotification(iconType, false);
        }
        Debug.Log("[GameManager] All notifications cleared");
    }
}

/// <summary>
/// Enum defining types of icons that can have notifications
/// </summary>
public enum IconType
{
    Player,
    Balo,
    Task,
    Score
}