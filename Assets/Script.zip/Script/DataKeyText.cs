﻿public static class DataKeyText
{
    public const string openText = "Chào em, hôm nay em đến để bắt đầu buổi học đúng không?"; // openText
    public const string text1 = "Em đã điểm danh buổi hôm nay, chúng ta bắt đầu vào học nhé"; // confirmText
    public const string text2 = "Không phải giờ môn này, quay lại đúng ca nhé."; // wrongTimeText
    public const string text3 = "Đang học..."; // learningText
}
