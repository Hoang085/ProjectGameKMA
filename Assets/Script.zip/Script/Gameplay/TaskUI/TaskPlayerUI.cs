﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class TaskPlayerUI : MonoBehaviour
{
    [Serializable] public class SubjectName { public string key; public string display; }
    [Serializable] class SubjectNameList { public List<SubjectName> items = new(); }

    [Header("Subject display mapping (JSON in Resources)")]
    [SerializeField] private string jsonPathInResources = "TextSubjectDisplay/subjectname";
    [SerializeField] private bool normalizeKeyOnLoad = false;

    [Header("UI parents")]
    [SerializeField] private Transform contentRoot;

    [Header("Prefabs")]
    [SerializeField] private GameObject boxTaskPrefab;

    [Header("Navigation")]
    [SerializeField] private bool enableNavigation = true;
    [SerializeField] private float navigationDuration = 30f;

    [Min(0)][SerializeField] private int showTaskMinutesEarly = 5;

    // Optional: tắt hoàn toàn popup dẫn đường
    [Header("Behaviour")]
    [SerializeField] private bool showNavigationPopup = false; // ← để false

    private readonly Dictionary<string, BoxTask> activeTasks = new();
    private readonly Dictionary<string, string> subjectDisplayMap = new();

    private GameObject panelRoot;
    private GameClock clock;
    private AttendanceManager attendanceManager;
    private Coroutine refreshCoroutine;

    void Awake()
    {
        InitializeComponents();
        LoadSubjectNamesFromJson();
    }

    void OnEnable()
    {
        EnsurePanelActive();
        SubscribeToEvents();
        StartRefreshLoop();
    }

    void OnDisable()
    {
        UnsubscribeFromEvents();
        StopRefreshLoop();
    }

    void InitializeComponents()
    {
        clock = GameClock.Ins;
        attendanceManager = FindAnyObjectByType<AttendanceManager>();

        panelRoot = transform.Find("ChildBackground")?.gameObject;
        if (!contentRoot)
            contentRoot = transform.Find("ChildBackground/Scroll View/Viewport/Content");

        EnsurePanelActive();
    }

    void EnsurePanelActive()
    {
        if (panelRoot && !panelRoot.activeSelf)
            panelRoot.SetActive(true);
    }

    void LoadSubjectNamesFromJson()
    {
        if (string.IsNullOrEmpty(jsonPathInResources)) return;

        var textAsset = Resources.Load<TextAsset>(jsonPathInResources);
        if (!textAsset) return;

        try
        {
            var list = JsonUtility.FromJson<SubjectNameList>(textAsset.text);
            if (list?.items == null) return;

            subjectDisplayMap.Clear();
            foreach (var item in list.items)
            {
                if (item == null || string.IsNullOrEmpty(item.key) || string.IsNullOrEmpty(item.display))
                    continue;

                var key = normalizeKeyOnLoad ? NormalizeKey(item.key) : item.key;
                subjectDisplayMap[key] = item.display;
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"[TaskPlayerUI] Error loading subject names: {ex.Message}");
        }
    }

    string NormalizeKey(string key) => key.Replace(" ", "").Replace("_", "").ToLowerInvariant();

    void SubscribeToEvents()
    {
        if (clock != null)
        {
            clock.OnSlotStarted += OnSlotStarted;
            clock.OnSlotEnded += OnSlotEnded;
        }
    }

    void UnsubscribeFromEvents()
    {
        if (clock != null)
        {
            clock.OnSlotStarted -= OnSlotStarted;
            clock.OnSlotEnded -= OnSlotEnded;
        }
    }

    void OnSlotStarted(int week, string dayEN, int slot1)
    {
        EnsurePanelActive();
        RefreshTasks();
    }

    void OnSlotEnded(int week, string dayEN, int slot1)
    {
        ClearAllTasks();
        EnsurePanelActive();

        if (enableNavigation && NavigationLineManager.Instance != null)
            NavigationLineManager.Instance.ClearNavigationLine();
    }

    void StartRefreshLoop()
    {
        if (gameObject.activeInHierarchy)
            refreshCoroutine = StartCoroutine(RefreshLoop());
    }

    void StopRefreshLoop()
    {
        if (refreshCoroutine != null)
        {
            StopCoroutine(refreshCoroutine);
            refreshCoroutine = null;
        }
    }

    IEnumerator RefreshLoop()
    {
        yield return null;
        while (gameObject.activeInHierarchy)
        {
            RefreshTasks();
            yield return new WaitForSeconds(3f);
        }
        refreshCoroutine = null;
    }

    void RefreshTasks()
    {
        EnsurePanelActive();

        if (!IsValidState())
        {
            ClearAllTasks();
            return;
        }

        var currentSubject = GetCurrentSubject();
        if (currentSubject == null)
        {
            ClearAllTasks();
            return;
        }

        ProcessSubjectTask(currentSubject);
    }

    bool IsValidState() => clock != null && attendanceManager != null;

    SubjectData GetCurrentSubject()
    {
        try
        {
            int semIndex = Mathf.Clamp(clock.Term - 1, 0, attendanceManager.semesterConfigs.Length - 1);
            var semester = attendanceManager.semesterConfigs[semIndex];
            return SemesterConfigUtil.instance.GetSubjectAt(semester, clock.Weekday, clock.GetSlotIndex1Based());
        }
        catch (Exception ex)
        {
            Debug.LogError($"[TaskPlayerUI] Error getting current subject: {ex.Message}");
            return null;
        }
    }

    void ProcessSubjectTask(SubjectData subject)
    {
        string subjectKey = KeyUtil.MakeKey(subject.Name);
        string subjectDisplayName = GetDisplayName(subjectKey);
        string taskKey = $"study:{subjectKey}";

        if (ShouldShowTask(subjectDisplayName, out int windowStart, out int windowEnd))
            CreateStudyTask(taskKey, subjectDisplayName, subjectKey, windowStart);
        else
            RemoveTask(taskKey);
    }

    bool ShouldShowTask(string subjectName, out int windowStart, out int windowEnd)
    {
        windowStart = windowEnd = 0;
        bool canCheckIn = attendanceManager.CanCheckInNow(subjectName, out windowStart, out windowEnd);
        if (canCheckIn) return true;
        return ShouldShowEarlyNotification(out windowStart, out windowEnd);
    }

    bool ShouldShowEarlyNotification(out int windowStart, out int windowEnd)
    {
        windowStart = windowEnd = 0;

        var clockUI = FindAnyObjectByType<ClockUI>();
        if (clockUI == null || attendanceManager.slotPolicy == null) return false;

        int currentMinute = clockUI.GetMinuteOfDay();
        int slotStart = attendanceManager.GetSlotStart(clock.Slot);

        if (attendanceManager.slotPolicy.TryGetWindow(clock.Slot, slotStart, out int winStart, out int winEnd))
        {
            int earlyStartTime = winStart - showTaskMinutesEarly;
            bool shouldShow = (currentMinute >= earlyStartTime) && (currentMinute < winEnd);
            if (shouldShow)
            {
                windowStart = winStart;
                windowEnd = winEnd;
                return true;
            }
        }
        return false;
    }

    void CreateStudyTask(string taskKey, string subjectDisplayName, string subjectKey, int windowStart)
    {
        if (!boxTaskPrefab || !contentRoot) return;

        string timeStr = ClockUI.FormatHM(windowStart);
        string slotName = GetSlotDisplayName(clock.Slot);

        string title = $"Sắp đến giờ học môn {subjectDisplayName}";
        string detail = $"Bắt đầu từ {timeStr} - {slotName}";
        string buttonText = "Đi học";
        string searchData = $"{subjectDisplayName}|{subjectKey}";

        CreateOrUpdateTask(taskKey, title, detail, buttonText, OnClickGoToTeacher, searchData);
    }

    // ===== Navigation =====
    void OnClickGoToTeacher(string searchData)
    {
        string[] parts = searchData.Split('|');
        string displayName = parts[0];
        string subjectKey = parts.Length > 1 ? parts[1] : displayName;

        var targetTeacher = FindTeacherForSubject(displayName, subjectKey);
        if (targetTeacher != null)
        {
            NavigateToTeacher(targetTeacher, displayName);
        }
        else
        {
            // Không mở popup – chỉ im lặng nếu không thấy (hoặc bạn có thể log cảnh báo trong Console)
            Debug.LogWarning($"[TaskPlayerUI] Teacher not found for subject '{displayName}'");
        }
    }

    TeacherAction FindTeacherForSubject(string displayName, string subjectKey)
    {
        var teachers = FindObjectsByType<TeacherAction>(FindObjectsSortMode.None);
        foreach (var teacher in teachers)
        {
            if (teacher.subjects == null) continue;
            foreach (var subject in teacher.subjects)
            {
                if (subject == null) continue;
                if (IsSubjectMatch(subject.subjectName, displayName, subjectKey))
                    return teacher;
            }
        }
        return null;
    }

    bool IsSubjectMatch(string teacherSubjectName, string displayName, string subjectKey)
    {
        if (string.IsNullOrEmpty(teacherSubjectName)) return false;

        if (string.Equals(teacherSubjectName, displayName, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(teacherSubjectName, subjectKey, StringComparison.OrdinalIgnoreCase))
            return true;

        string nTeacher = NormalizeKey(teacherSubjectName);
        string nDisplay = NormalizeKey(displayName);
        string nKey = NormalizeKey(subjectKey);

        return string.Equals(nTeacher, nDisplay, StringComparison.OrdinalIgnoreCase) ||
               string.Equals(nTeacher, nKey, StringComparison.OrdinalIgnoreCase);
    }

    void NavigateToTeacher(TeacherAction teacher, string subjectName)
    {
        // Gọi vẽ line nếu bật dẫn đường
        if (enableNavigation && NavigationLineManager.Instance != null)
            NavigationLineManager.Instance.CreateNavigationLine(teacher.transform, $"GV {teacher.name} - {subjectName}");

        // Ẩn toàn bộ panel Task
        gameObject.SetActive(false);

        // KHÔNG mở popup “Dẫn đường”
        if (showNavigationPopup && GameUIManager.Ins != null)
        {
            GameUIManager.Ins.OpenDialogue("Dẫn đường",
                $"Đang dẫn đường tới giảng viên {teacher.name} dạy môn {subjectName}.");
        }
    }

    // ===== Task UI =====
    void CreateOrUpdateTask(string key, string title, string detail, string btnText,
                           System.Action<string> onClick, string clickArg)
    {
        if (!activeTasks.TryGetValue(key, out var task))
        {
            task = CreateNewTask();
            if (task == null) return;
            activeTasks[key] = task;
        }
        task.Setup(key, title, detail, btnText, onClick, clickArg);
    }

    BoxTask CreateNewTask()
    {
        if (!boxTaskPrefab || !contentRoot) return null;
        var go = Instantiate(boxTaskPrefab, contentRoot);
        var box = go.GetComponent<BoxTask>();
        if (box == null) { DestroyImmediate(go); return null; }
        go.SetActive(true);
        return box;
    }

    void RemoveTask(string key)
    {
        if (activeTasks.TryGetValue(key, out var task))
        {
            activeTasks.Remove(key);
            if (task != null && task.gameObject != null)
                DestroyImmediate(task.gameObject);
        }
    }

    void ClearAllTasks()
    {
        foreach (var kvp in activeTasks)
            if (kvp.Value != null && kvp.Value.gameObject != null)
                DestroyImmediate(kvp.Value.gameObject);
        activeTasks.Clear();
    }

    string GetDisplayName(string keyOrFallback)
    {
        if (string.IsNullOrEmpty(keyOrFallback)) return keyOrFallback;
        var key = normalizeKeyOnLoad ? NormalizeKey(keyOrFallback) : keyOrFallback;
        if (subjectDisplayMap.TryGetValue(key, out var display)) return display;

        return System.Globalization.CultureInfo.CurrentCulture.TextInfo
               .ToTitleCase(key.Replace('_', ' ').ToLowerInvariant());
    }

    string GetSlotDisplayName(DaySlot slot) => slot switch
    {
        DaySlot.MorningA => "Buổi sáng - Ca 1",
        DaySlot.MorningB => "Buổi sáng - Ca 2",
        DaySlot.AfternoonA => "Buổi chiều - Ca 3",
        DaySlot.AfternoonB => "Buổi chiều - Ca 4",
        DaySlot.Evening => "Buổi tối - Ca 5",
        _ => slot.ToString()
    };
}
