﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class BoxTask : MonoBehaviour
{
    [SerializeField] private TMP_Text titleText;   // BoxText/TittleText hoặc TitleText
    [SerializeField] private TMP_Text detailText;  // BoxText/ChildText
    [SerializeField] private Button actionBtn;     // BoxBtn

    public string Key { get; private set; }

    public void Setup(string key, string title, string detail, string buttonText, Action<string> onClick, string clickArg)
    {
        Key = key;

        if (!titleText)
            titleText = transform.Find("BoxText/TittleText")?.GetComponent<TMP_Text>()
                     ?? transform.Find("BoxText/TitleText")?.GetComponent<TMP_Text>();
        if (!detailText)
            detailText = transform.Find("BoxText/ChildText")?.GetComponent<TMP_Text>();
        if (!actionBtn)
            actionBtn = transform.Find("BoxBtn")?.GetComponent<Button>();

        if (titleText) titleText.text = title;
        if (detailText) detailText.text = detail;

        var btnLabel = actionBtn ? actionBtn.GetComponentInChildren<TMP_Text>() : null;
        if (btnLabel && !string.IsNullOrEmpty(buttonText)) btnLabel.text = buttonText;

        if (actionBtn)
        {
            actionBtn.onClick.RemoveAllListeners();
            // Truyền clickArg (ở đây mình sẽ truyền subjectName)
            actionBtn.onClick.AddListener(() => onClick?.Invoke(clickArg));
        }
    }
}
