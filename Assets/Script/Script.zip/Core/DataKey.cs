public static class DataKey 
{
    public static string SPEED = "Speed";
    public static string ISGROUND = "IsGrounded";
    public static string JUMP = "Jump";
}
